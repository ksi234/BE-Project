s = "Engine 1"
b = bytearray()
b.extend(map(ord, s))





print(d)