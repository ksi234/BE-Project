
import time
import board
import busio
import requests

# Additional import needed for I2C/SPI
# from digitalio import DigitalInOut


from adafruit_pn532.adafruit_pn532 import MIFARE_CMD_AUTH_B
from adafruit_pn532.i2c import PN532_I2C



# I2C connection:
i2c = busio.I2C(board.SCL, board.SDA)

# Non-hardware reset/request with I2C
pn532 = PN532_I2C(i2c, debug=False)




print("Enter ID : ")
print("Enter Asset Info : ")
time.sleep(10)
a = str(input())
ast_info = str(input())

# For String 
data1 = bytearray(0)
data1.extend(map(ord, ast_info))

n = 16 - len(data1)
for x in range(0,n):
    data1.insert(0,0)
    n-1




mylist = [int(d) for d in a]

n = 16 - len(mylist)
for x in range(0,n):
    mylist.insert(0,0)
    n-1


# With I2C, we recommend connecting RSTPD_N (reset) to a digital pin for manual


ic, ver, rev, support = pn532.firmware_version
print("Found PN532 with firmware version: {0}.{1}".format(ver, rev))

# Configure PN532 to communicate with MiFare cards
pn532.SAM_configuration()

print("Waiting for RFID/NFC card to write to!")

key = b"\xFF\xFF\xFF\xFF\xFF\xFF"

while True:
    # Check if a card is available to read
    uid = pn532.read_passive_target(timeout=0.5)
    print(".", end="")
    # Try again if no card is available.
    if uid is not None:
        break

print("")

print("Found card with UID:", [hex(i) for i in uid])
print("Authenticating...")

authenticated = pn532.mifare_classic_authenticate_block(uid, 5, MIFARE_CMD_AUTH_B, key)
if not authenticated:
    print("Authentication failed!")

# Set 16 bytes of block to 0xFEEDBEEF


data = bytearray(16)
data = bytearray(mylist)



# Write 16 byte block.
pn532.mifare_classic_write_block(0, data)

#Writing Asset Info on to the card
pn532.mifare_classic_write_block(6, data1)
# Read block #5
print(
    "Wrote to NFC Tag",    
)





