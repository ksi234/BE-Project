
import time
import board
import busio
import requests

# Additional import needed for I2C/SPI
# from digitalio import DigitalInOut


from adafruit_pn532.adafruit_pn532 import MIFARE_CMD_AUTH_B
from adafruit_pn532.i2c import PN532_I2C



# I2C connection:
i2c = busio.I2C(board.SCL, board.SDA)

# Non-hardware reset/request with I2C
pn532 = PN532_I2C(i2c, debug=False)




print("Enter ID")
time.sleep(10)
a = str(input())


mylist = [int(d) for d in a]

n = 16 - len(mylist)
for x in range(0,n):
    mylist.insert(0,0)
    n-1


# With I2C, we recommend connecting RSTPD_N (reset) to a digital pin for manual


ic, ver, rev, support = pn532.firmware_version
print("Found PN532 with firmware version: {0}.{1}".format(ver, rev))

# Configure PN532 to communicate with MiFare cards
pn532.SAM_configuration()

print("Waiting for RFID/NFC card to write to!")

key = b"\xFF\xFF\xFF\xFF\xFF\xFF"

while True:
    # Check if a card is available to read
    uid = pn532.read_passive_target(timeout=0.5)
    print(".", end="")
    # Try again if no card is available.
    if uid is not None:
        break

print("")

print("Found card with UID:", [hex(i) for i in uid])
print("Authenticating block 5 ...")

authenticated = pn532.mifare_classic_authenticate_block(uid, 5, MIFARE_CMD_AUTH_B, key)
if not authenticated:
    print("Authentication failed!")

# Set 16 bytes of block to 0xFEEDBEEF


data = bytearray(16)
data = bytearray(mylist)



# Write 16 byte block.
pn532.mifare_classic_write_block(5, data)
# Read block #5
print(
    "Wrote to block 5, now trying to read that data:",
    [int(hex(x),16) for x in pn532.mifare_classic_read_block(5)],
)


data1 = [int(hex(x),16) for x in pn532.mifare_classic_read_block(5)]

strings = [str(integer) for integer in data1 ]

a = "".join(strings)

b = int(a)

print(b)





url_cloudserver = "https://wadiacsi1.cognitonetworks.com/cognito/entitycore/2184" # entity ID will be provided.

payload="{\n  \"entityid\": \"2184\",\n    \"entityName\": \"test\",\n    \"entityTag\": \"234\",\n "\
            "\"gatewayid\": \"361\",\n  \"status\": true,\n "\
            "\"datastreams\": [\n    {\n      \"name\": \"Temp\",\n "\
            "\"value\":\"65\",\n      \"units\": \"DegF\",\n "\
            "\"ContentFormat\": \"\",\n      \"type\": \"Number\"\n    },\n "\
            "{\n      \"name\": \"Press\",\n      \"value\":\"23\",\n "\
            "\"units\": \"Pa\",\n      \"ContentFormat\": \"\",\n      \"type\": \"Number\"\n    }\n  ]\n}"
headers = {
    'Apikey': 'K9MkyEo5fM0YracivwW3', # API Key to be provided
    'Content-Type': 'text/plain'
    }

print(payload)
response = requests.request("POST", url_cloudserver, headers=headers, data=payload)

print(response.text)









