
import time
import board
import busio
import requests
from datetime import datetime
import pytz


# Additional import needed for I2C/SPI
# from digitalio import DigitalInOut


from adafruit_pn532.adafruit_pn532 import MIFARE_CMD_AUTH_B
from adafruit_pn532.i2c import PN532_I2C



# I2C connection:
i2c = busio.I2C(board.SCL, board.SDA)

# Non-hardware reset/request with I2C
pn532 = PN532_I2C(i2c, debug=False)






# With I2C, we recommend connecting RSTPD_N (reset) to a digital pin for manual


while True:
    ic, ver, rev, support = pn532.firmware_version
    print("Found PN532 with firmware version: {0}.{1}".format(ver, rev))

    # Configure PN532 to communicate with MiFare cards
    pn532.SAM_configuration()

    print("Waiting for RFID/NFC card to read from !")

    key = b"\xFF\xFF\xFF\xFF\xFF\xFF"

    while True:
        # Check if a card is available to read
        uid = pn532.read_passive_target(timeout=0.5)
        print(".", end="")
        # Try again if no card is available.
        if uid is not None:
            break

    print("")

    print("Found card with UID:", [hex(i) for i in uid])
    print("Authenticating block...")
    authenticated = pn532.mifare_classic_authenticate_block(uid, 5, MIFARE_CMD_AUTH_B, key)
    if not authenticated:
        print("Authentication failed!")
    #for i in range (5,128):
    #if pn532.mifare_classic_read_block(i)!= None:
   
    
    
    
    data1 = [int(hex(x),16) for x in pn532.mifare_classic_read_block(5)]
    
    #print(data1)
    a = ""
    for i in range (len(data1)):
        if data1[i]!=0 and data1[i]<123:
            a = a + chr(int(data1[i]))
    
    
    
    
    
    data1 = [int(hex(x),16) for x in pn532.mifare_classic_read_block(6)]
    
    #print(data1)
    b = ""
    for i in range (len(data1)):
        if data1[i]!=0 and data1[i]<123:
            b = b + chr(int(data1[i]))
            
    res =  a+b
    z = res.split(";",4)
    print("Entity ID : ",a[1:5])
    print("Entity Name : ",z[1])
    print("AssetInfo : ",z[2])
    asset_info = z[2]
    #IST=pytz.timezone ('Asia/Kolkata')
    #dt1 = datetime.now(pytz.timezone(IST))
    IST = pytz.timezone('Asia/Kolkata')
    dt2 = datetime.now(IST)
     
    dt = dt2.strftime("%d/%m/%Y %H:%M:%S")
    
    time.sleep(5)



    # Read block #5


#     
#     
    url = "https://wadiacsi1.cognitonetworks.com/cognito/entitycore/2202"

    payload = '{\n    \"entityid\":\"2202\",\n    \"entityName\":\"ParkingSpot6\",\n    \"entityTag\":\"ParkingSpot\",\n    \"gatewayid\":\"Sub_Assembly_Parking\",\n    \"status\":true,\n    \"datastreams\":[\n        {\n            \"name\":\"Parking_Inf\",\n           \"value\": \"63;38;82;84;T676;21-12-2021 12:20:23;21-12-2021 12:20:23;%s;P124\",\n            \"units\":\"\",\n\"ContentFormat\":\"\",\n            \"type\": \"String\"\n       \n        }\n    ]\n}'%(asset_info)
    #print(payload)
    headers = {
      'Apikey': 'K9MkyEo5fM0YracivwW3',
      'Authorization': 'K9MkyEo5fM0YracivwW3 5xn-c646006da1934235e084 81 111',
      'Content-Type': 'text/plain'   }       
    response = requests.request("POST", url, headers=headers, data=payload) 
    print(response.text)
    time.sleep(10)
    
    
    
     #"value": "63;38;82;84;T676;21-12-2021 12:20:23;21-12-2021 12:20:23;Maruti;P124"
    
    
    
    
    
    




