package com.peerbits.nfccardread;

import android.app.DialogFragment;
import android.content.Context;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.tech.Ndef;
import android.os.Bundle;
//import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.nio.charset.Charset;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class NFCWriteFragment extends DialogFragment {

    public static final String TAG = NFCWriteFragment.class.getSimpleName();

    public static NFCWriteFragment newInstance() {

        return new NFCWriteFragment();
    }

    private TextView mTvMessage;
    private ProgressBar mProgress;
    private Listener mListener;
    public String assetInfo;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_write,container,false);
        initViews(view);
        return view;
    }

    private void initViews(View view) {

        mTvMessage = (TextView) view.findViewById(R.id.tv_message);
        mProgress = (ProgressBar) view.findViewById(R.id.progress);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mListener = (NFCWrite)context;
        mListener.onDialogDisplayed();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener.onDialogDismissed();
    }

    public void onNfcDetected(Ndef ndef, String messageToWrite){

        mProgress.setVisibility(View.VISIBLE);
        writeToNfc(ndef,messageToWrite);
    }



    public String postID ;
    public String postName;
    public void postokhttpdata() {
        if(NFCWrite.config==1){
            postID = CreateEntity.seID;
            postName = CreateEntity.seName;
        }
        else{
            postID = NFCWrite.takenID;
            postName = NFCWrite.takenName;
        }


        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "{\n    \"entityid\":\"" + postID + "\",\n    \"entityName\":\"" + postName + "\",\n    \"entityTag\":\"Generic\",\n    \"gatewayid\":\"Sub_Assembly_Parking\",\n    \"status\":true,\n    \"datastreams\":[\n        {\n            \"name\":\"asset_inf\",\n            \"value\":\"" + assetInfo + "\",\n            \"units\":\"\",\n            \"ContentFormat\":\"\",\n            \"type\": \"String\"\n        }  \n    ]\n}");
        Request request = new Request.Builder()
                .url("https://wadiacsi1.cognitonetworks.com/cognito/entitycore/" + postID + "")
                .method("POST", body)
                .addHeader("Apikey", "K9MkyEo5fM0YracivwW3")
                .addHeader("Authorization", "K9MkyEo5fM0YracivwW3 5xn-c646006da1934235e084 81 111")
                .addHeader("Content-Type", "text/plain")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {

            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {

            }
        });







        OkHttpClient client1 = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType1 = MediaType.parse("text/plain");
        RequestBody body1 = RequestBody.create(mediaType1, "{\n    \"entityid\":\""+postID+"\",\n    \"entityName\":\""+postName+"\",\n    \"entityTag\":\"Generic\",\n    \"gatewayid\":\"Sub_Assembly_Parking\",\n    \"status\":true,\n    \"datastreams\":[\n        {\n            \"name\":\"entity_inf\",\n            \"value\":\""+postID+";"+postName+"\",\n            \"units\":\"\",\n            \"ContentFormat\":\"\",\n            \"type\": \"String\"\n        }  \n    ]\n}");
        Request request1 = new Request.Builder()
                .url("https://wadiacsi1.cognitonetworks.com/cognito/entitycore/"+postID+"")
                .method("POST", body1)
                .addHeader("Apikey", "K9MkyEo5fM0YracivwW3")
                .addHeader("Authorization", "K9MkyEo5fM0YracivwW3 5xn-c646006da1934235e084 81 111")
                .addHeader("Content-Type", "text/plain")
                .build();

        Call call1 = client1.newCall(request1);
        call1.enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {

            }
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {

            }
        });





    }



        public String wmsg;
        private void writeToNfc(Ndef ndef, String message){

            mTvMessage.setText(getString(R.string.message_write_progress));
        if (ndef != null) {

            try {
                ndef.connect();
                if(NFCWrite.config==1){
                    wmsg = CreateEntity.seID + ";" +CreateEntity.seName + ";" + message + ";";
                }
                else{
                    wmsg = NFCWrite.takenID + ";" +NFCWrite.takenName  + ";" + message  + ";";
                }

                NdefRecord mimeRecord = NdefRecord.createMime("text/plain", wmsg.getBytes(Charset.forName("US-ASCII")));

                ndef.writeNdefMessage(new NdefMessage(mimeRecord));
                assetInfo = message;
                postokhttpdata();
                ndef.close();
                //Write Successful
                mTvMessage.setText(getString(R.string.message_write_success));
                NFCWrite.config = 0;

            } catch (IOException | FormatException e) {
                e.printStackTrace();
                mTvMessage.setText(getString(R.string.message_write_error));

            } finally {
                mProgress.setVisibility(View.GONE);
            }

        }
    }
}
