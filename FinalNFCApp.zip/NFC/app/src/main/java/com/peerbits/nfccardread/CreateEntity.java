package com.peerbits.nfccardread;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import okhttp3.*;



import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import okhttp3.RequestBody;



public class CreateEntity extends Activity {

    public static final String TAG = NFCWrite.class.getSimpleName();
    private EditText evTagMessage;
    private EditText evTagMessage1;
    private EditText sendData;
    private NfcAdapter mNfcAdapter;
    private boolean isWrite = true;
    private ImageView ivBack;
    private Button btnSend;
    private Button btnCreate;
    public static String seID  ;
    public static String seName;
    private EditText newT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_entity);

        btnCreate = (Button) findViewById(R.id.btnCreate);
        initViews();
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postokhttpdata();
            }
        });}

    public void postokhttpdata(){

       // evTagMessage1 = findViewById(R.id.sendData);

        String  entitydata = evTagMessage1.getText().toString();

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "{\n    \"entityid\":\""+ entitydata + "\",\n    \"entityName\":\""+entitydata+"\",\n    \"entityTag\":\"Generic\",\n    \"gatewayid\":\"Sub_Assembly_Parking\",\n    \"status\":true,\n    \"characteristics\":[\n       \n    ]\n}");
        Request request = new Request.Builder()
                .url("https://wadiacsi1.cognitonetworks.com/cognito/entitycore/autodiscovery/")
                .method("POST", body)
                .addHeader("Apikey", "K9MkyEo5fM0YracivwW3")
                .addHeader("Content-Type", "text/plain")
                .build();
        Response response = null;

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {

            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {

                try {
                    JSONObject object = new JSONObject(response.body().string());
                    seID = object.getString("aEntityId");
                    seName = evTagMessage1.getText().toString();

                    //evTagMessage1.setText("Entity ID : " + seID  + "  Created Successfully");
                    //Toast.makeText(CreateEntity.this, "Successfully Created", Toast.LENGTH_LONG).show();

            } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

            private void initViews() {
                ivBack = findViewById(R.id.ivBack);
                evTagMessage1 = findViewById(R.id.sendData);
                //evTagMessage = findViewById(R.id.evTagMessage);
                mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
            }
         }


