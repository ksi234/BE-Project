package com.peerbits.nfccardread;

import android.app.Activity;
import android.content.ContextParams;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;

import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;




public class NfcHome extends Activity implements View.OnClickListener {

    public static final String TAG = NfcHome.class.getSimpleName();
    private RelativeLayout rlRead;
    private RelativeLayout rlWrite;
    private RelativeLayout newEntity;
    private RelativeLayout writeOnTag;
    private ImageView ivHomeicon;
    private Animation mAnimation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nfc_home);
        initViews();
        rlRead.setOnClickListener(this);
        rlWrite.setOnClickListener(this);
        newEntity.setOnClickListener(this);
        //writeOnTag.setOnClickListener(this);



            }





    private void initViews() {

        rlRead = findViewById(R.id.rlReadNFCTAG);
        rlWrite = findViewById(R.id.rlWriteWithNFC);
        newEntity = findViewById(R.id.newEntity);
        //writeOnTag = findViewById(R.id.writeOnTag);
        ivHomeicon = findViewById(R.id.ivHomeicon);
        mAnimation = AnimationUtils.loadAnimation(NfcHome.this, R.anim.swinging);
    }


    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.rlReadNFCTAG:
                intent = new Intent(this, NFCRead.class);
                this.startActivity(intent);
                break;

            case R.id.rlWriteWithNFC:
                intent = new Intent(this, NFCWrite.class);
                this.startActivity(intent);
                break;

            case R.id.newEntity:
                intent = new Intent(this, CreateEntity.class);
                this.startActivity(intent);
                break;


//            case R.id.writeOnTag:
//                intent = new Intent(this, WriteOnTag.class);
//                this.startActivity(intent);
//                break;


        }
    }

    @Override
    public void onResume() {
        super.onResume();
        ivHomeicon.startAnimation(mAnimation);
    }

    @Override
    public void onPause() {
        ivHomeicon.clearAnimation();
        super.onPause();
    }
}
