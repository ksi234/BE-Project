package com.peerbits.nfccardread;

public interface Listener {

    void onDialogDisplayed();

    void onDialogDismissed();
}
